package com.destroyerpvp;

import com.destroyerpvp.gui.ClickGuiScreen;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import org.lwjgl.glfw.GLFW;

public class DestroyerPvP implements ClientModInitializer {
    public static final String MOD_ID = "destroyerpvp";
    private static KeyMapping menuKey;

    @Override
    public void onInitializeClient() {
        ModuleManager.init();

        menuKey = KeyBindingHelper.registerKeyBinding(new KeyMapping(
                "key.destroyerpvp.menu",
                GLFW.GLFW_KEY_0,
                "category.destroyerpvp"
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (menuKey.consumeClick()) {
                if (client.screen == null) {
                    client.setScreen(new ClickGuiScreen());
                }
            }
            ModuleManager.tick(client);
        });
    }
}
